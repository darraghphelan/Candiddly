package com.example.candiddly

class User(username: String, email: String) {

}
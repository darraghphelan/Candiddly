package com.example.candiddly

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

private lateinit var listView: ListView

class FriendsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)

        listView = findViewById<ListView>(R.id.friends_list_view)
        val friendList = listOf<String>("Dan", "Aidan", "Arran")
        val listItems = arrayOfNulls<String>(friendList.size)
        for (i in 0 until friendList.size) {
            val friend = friendList[i]
            listItems[i] = friend
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems)
        listView.adapter = adapter
    }
}
